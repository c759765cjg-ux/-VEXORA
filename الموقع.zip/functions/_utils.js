const enc = new TextEncoder();

export function json(data, status = 200, extra = {}) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store", ...extra } });
}

export function cookie(name, value, opts = {}) {
  const parts = [`${name}=${value}`, `Path=${opts.path || "/"}`];
  if (opts.maxAge !== undefined) parts.push(`Max-Age=${opts.maxAge}`);
  if (opts.httpOnly !== false) parts.push("HttpOnly");
  if (opts.secure !== false) parts.push("Secure");
  parts.push(`SameSite=${opts.sameSite || "Lax"}`);
  return parts.join("; ");
}

export function getCookie(request, name) {
  const raw = request.headers.get("Cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === name) return rest.join("=");
  }
  return null;
}

function hex(buf) {
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function hmac(secret, value) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, enc.encode(value)));
}

export async function randomHex(bytes = 32) {
  return hex(crypto.getRandomValues(new Uint8Array(bytes)).buffer);
}

export async function createSession(env, user, token) {
  const id = await randomHex(32);
  const now = Math.floor(Date.now() / 1000);
  const expires = now + 60 * 60 * 24 * 7;
  const accessExpires = now + Number(token.expires_in || 3600);
  await env.DB.prepare(`INSERT INTO sessions(id,user_id,username,access_token,refresh_token,expires_at,access_expires_at) VALUES(?,?,?,?,?,?,?)`)
    .bind(id, user.id, user.username || "", token.access_token, token.refresh_token || "", expires, accessExpires).run();
  const sig = await hmac(env.SESSION_SECRET, id);
  return { value: `${id}.${sig}`, maxAge: expires - now };
}

export async function getSession(request, env) {
  const value = getCookie(request, "vx_session");
  if (!value) return null;
  const [id, sig] = value.split(".");
  if (!id || !sig || !env.SESSION_SECRET) return null;
  const expected = await hmac(env.SESSION_SECRET, id);
  if (sig.length !== expected.length) return null;
  if (sig !== expected) return null;
  const row = await env.DB.prepare(`SELECT * FROM sessions WHERE id=?`).bind(id).first();
  if (!row || Number(row.expires_at) <= Math.floor(Date.now() / 1000)) return null;
  return row;
}

export async function requireOwner(request, env) {
  const session = await getSession(request, env);
  if (!session) return { error: json({ error: "يجب تسجيل الدخول بحساب Discord أولاً." }, 401) };
  if (!env.OWNER_DISCORD_ID || session.user_id !== env.OWNER_DISCORD_ID)
    return { error: json({ error: "ليس لديك صلاحية الوصول لهذه الصفحة." }, 403) };
  return { session };
}

export function discordHeaders(token) {
  return { Authorization: `Bearer ${token}` };
}

export async function discordFetch(url, init = {}) {
  return fetch(url, { ...init, headers: { "User-Agent": "VEXORA Website", ...(init.headers || {}) } });
}

export async function refreshSession(session, env) {
  if (!session?.refresh_token || !env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET) return session;
  const now = Math.floor(Date.now() / 1000);
  if (Number(session.access_expires_at || 0) > now + 60) return session;
  const form = new URLSearchParams({ client_id: env.DISCORD_CLIENT_ID, client_secret: env.DISCORD_CLIENT_SECRET, grant_type: "refresh_token", refresh_token: session.refresh_token });
  const r = await fetch("https://discord.com/api/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form });
  const t = await r.json().catch(() => ({}));
  if (!r.ok || !t.access_token) return session;
  const accessExpires = now + Number(t.expires_in || 3600);
  await env.DB.prepare("UPDATE sessions SET access_token=?, refresh_token=?, access_expires_at=? WHERE id=?")
    .bind(t.access_token, t.refresh_token || session.refresh_token, accessExpires, session.id).run();
  return { ...session, access_token: t.access_token, refresh_token: t.refresh_token || session.refresh_token, access_expires_at: accessExpires };
}
