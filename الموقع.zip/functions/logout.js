import { cookie, getSession } from "./_utils.js";
export async function onRequestGet({ request, env }) {
  const session = await getSession(request, env);
  if (session) await env.DB.prepare("DELETE FROM sessions WHERE id=?").bind(session.id).run();
  return new Response(null, { status: 302, headers: { Location: "/", "Set-Cookie": cookie("vx_session", "", { maxAge: 0 }) } });
}
