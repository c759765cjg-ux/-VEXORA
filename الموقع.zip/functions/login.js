import { cookie, randomHex } from "./_utils.js";
export async function onRequestGet({ request, env }) {
  if (!env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET || !env.DB || !env.SESSION_SECRET)
    return new Response("Discord OAuth غير مكتمل في إعدادات Cloudflare.", { status: 500 });
  const redirect = env.DISCORD_REDIRECT_URI || `${new URL(request.url).origin}/oauth/callback`;
  const state = await randomHex(24);
  const url = new URL("https://discord.com/oauth2/authorize");
  url.searchParams.set("client_id", env.DISCORD_CLIENT_ID);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("redirect_uri", redirect);
  url.searchParams.set("scope", "identify guilds");
  url.searchParams.set("state", state);
  const headers = new Headers({ Location: url.toString() });
  headers.append("Set-Cookie", cookie("vx_oauth_state", state, { maxAge: 600 }));
  return new Response(null, { status: 302, headers });
}
