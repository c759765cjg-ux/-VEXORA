import { requireOwner, json } from "../_utils.js";
export async function onRequestGet({ env }) {
  const row = await env.DB.prepare("SELECT title,text,image_url,enabled FROM announcement WHERE id=1").first();
  return json(row || {title:"",text:"",image_url:"",enabled:0});
}
export async function onRequestPost({ request, env }) {
  const auth = await requireOwner(request, env); if (auth.error) return auth.error;
  const body = await request.json().catch(()=>null);
  if (!body) return json({error:"بيانات غير صالحة."},400);
  const title = String(body.title || "").slice(0,120);
  const text = String(body.text || "").slice(0,2000);
  const image_url = String(body.image_url || "").slice(0,1000);
  const enabled = body.enabled ? 1 : 0;
  await env.DB.prepare("INSERT INTO announcement(id,title,text,image_url,enabled) VALUES(1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,text=excluded.text,image_url=excluded.image_url,enabled=excluded.enabled")
    .bind(title,text,image_url,enabled).run();
  return json({ok:true});
}
