import { requireOwner, json } from "../_utils.js";
export async function onRequestPost({ request, env }) {
  const auth = await requireOwner(request, env); if (auth.error) return auth.error;
  if (!env.MEDIA) return json({error:"تخزين الصور غير مربوط في Cloudflare (R2 باسم MEDIA)."},500);
  const type = request.headers.get("content-type") || "";
  if (!type.startsWith("multipart/form-data")) return json({error:"أرسل الصورة كملف."},400);
  const form = await request.formData();
  const file = form.get("image");
  if (!(file instanceof File)) return json({error:"لم يتم اختيار صورة."},400);
  if (!file.type.startsWith("image/")) return json({error:"الملف يجب أن يكون صورة."},400);
  if (file.size > 5 * 1024 * 1024) return json({error:"حجم الصورة يجب ألا يتجاوز 5MB."},400);
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const key = `announcements/${crypto.randomUUID()}.${ext}`;
  await env.MEDIA.put(key, file.stream(), { httpMetadata: { contentType: file.type, cacheControl: "public, max-age=31536000, immutable" } });
  const base = env.MEDIA_PUBLIC_URL;
  if (!base) return json({error:"أضف MEDIA_PUBLIC_URL في إعدادات Cloudflare."},500);
  return json({ok:true,url:`${base.replace(/\/$/,"")}/${key}`});
}
