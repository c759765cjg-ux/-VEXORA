import { requireOwner, json } from "../_utils.js";
export async function onRequestGet({ request, env }) {
  const a = await requireOwner(request, env); if (a.error) return a.error;
  return json({ok:true});
}
