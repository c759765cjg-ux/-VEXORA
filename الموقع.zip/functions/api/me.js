import { getSession, json } from "../_utils.js";
export async function onRequestGet({ request, env }) {
  const s = await getSession(request, env);
  if (!s) return json({ loggedIn: false });
  return json({ loggedIn: true, user: { id: s.user_id, username: s.username }, owner: s.user_id === env.OWNER_DISCORD_ID });
}
