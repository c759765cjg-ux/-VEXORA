import { getSession, refreshSession, json, discordFetch } from "../_utils.js";
const MANAGE_GUILD = 0x20n;
const ADMINISTRATOR = 0x8n;
function hasManage(g) {
  try { const p = BigInt(g.permissions || "0"); return g.owner === true || (p & MANAGE_GUILD) !== 0n || (p & ADMINISTRATOR) !== 0n; }
  catch { return false; }
}
export async function onRequestGet({ request, env }) {
  let s = await getSession(request, env);
  if (!s) return json({ error: "يجب تسجيل الدخول أولاً." }, 401);
  s = await refreshSession(s, env);
  let r = await discordFetch("https://discord.com/api/users/@me/guilds", { headers: { Authorization: `Bearer ${s.access_token}` } });
  if (r.status === 401) { s = await refreshSession({ ...s, access_expires_at: 0 }, env); r = await discordFetch("https://discord.com/api/users/@me/guilds", { headers: { Authorization: `Bearer ${s.access_token}` } }); }
  const guilds = await r.json().catch(() => []);
  if (!r.ok || !Array.isArray(guilds)) return json({ error: "تعذر جلب السيرفرات من Discord." }, 502);
  const allowed = guilds.filter(hasManage);
  let botId = null;
  if (env.DISCORD_BOT_TOKEN) {
    const br = await discordFetch("https://discord.com/api/users/@me", { headers: { Authorization: `Bot ${env.DISCORD_BOT_TOKEN}` } });
    if (br.ok) botId = (await br.json()).id;
  }
  const out = await Promise.all(allowed.map(async g => {
    let installed = false;
    if (env.DISCORD_BOT_TOKEN) {
      const gr = await discordFetch(`https://discord.com/api/guilds/${g.id}`, { headers: { Authorization: `Bot ${env.DISCORD_BOT_TOKEN}` } });
      installed = gr.ok;
    }
    return { id: g.id, name: g.name, icon: g.icon, installed, invite: `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(env.DISCORD_CLIENT_ID)}&permissions=${encodeURIComponent(env.DISCORD_BOT_PERMISSIONS || "0")}&scope=bot%20applications.commands&guild_id=${encodeURIComponent(g.id)}` };
  }));
  return json({ guilds: out, botId });
}
