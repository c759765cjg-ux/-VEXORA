import { cookie, getCookie, createSession, json, discordFetch } from "../_utils.js";

export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const saved = getCookie(request, "vx_oauth_state");
  if (!code || !state || !saved || state !== saved) return json({ error: "جلسة تسجيل الدخول غير صالحة." }, 400);

  const redirect = env.DISCORD_REDIRECT_URI || `${url.origin}/oauth/callback`;
  const form = new URLSearchParams({ client_id: env.DISCORD_CLIENT_ID, client_secret: env.DISCORD_CLIENT_SECRET, grant_type: "authorization_code", code, redirect_uri: redirect });
  const tokenRes = await fetch("https://discord.com/api/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form });
  const token = await tokenRes.json().catch(() => ({}));
  if (!tokenRes.ok || !token.access_token) return json({ error: "تعذر تسجيل الدخول من Discord." }, 502);

  const meRes = await discordFetch("https://discord.com/api/users/@me", { headers: { Authorization: `Bearer ${token.access_token}` } });
  const user = await meRes.json().catch(() => ({}));
  if (!meRes.ok || !user.id) return json({ error: "تعذر قراءة حساب Discord." }, 502);

  const session = await createSession(env, user, token);
  const headers = new Headers({ Location: "/" });
  headers.append("Set-Cookie", cookie("vx_session", session.value, { maxAge: session.maxAge }));
  headers.append("Set-Cookie", cookie("vx_oauth_state", "", { maxAge: 0 }));
  return new Response(null, { status: 302, headers });
}
