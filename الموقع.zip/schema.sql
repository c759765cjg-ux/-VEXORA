CREATE TABLE IF NOT EXISTS announcement (
 id INTEGER PRIMARY KEY,
 title TEXT NOT NULL DEFAULT '',
 text TEXT NOT NULL DEFAULT '',
 image_url TEXT NOT NULL DEFAULT '',
 enabled INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO announcement(id,title,text,image_url,enabled) VALUES (1,'📢 إعلان VEXORA','اكتب إعلانك من زر خاص إعلان.', '',0);

CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL,
 username TEXT NOT NULL DEFAULT '',
 access_token TEXT NOT NULL,
 refresh_token TEXT NOT NULL DEFAULT '',
 expires_at INTEGER NOT NULL,
 access_expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
