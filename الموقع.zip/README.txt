VEXORA — موقع + تسجيل Discord + اختيار السيرفر + خاص إعلان

الموجود:
- تسجيل الدخول بحساب Discord.
- عرض السيرفرات التي يملك المستخدم فيها صلاحية إدارة السيرفر فقط (Manage Server / Administrator / Owner).
- إذا كان البوت غير موجود يظهر زر إضافة البوت للسيرفر المحدد.
- زر «خاص إعلان» يظهر لصاحب الحساب المحدد في OWNER_DISCORD_ID فقط.
- نشر إعلان من Safari مع عنوان + نص + صورة.
- رفع صورة الإعلان إلى Cloudflare R2.
- إظهار/إخفاء الإعلان من الصفحة الرئيسية.

Cloudflare bindings:
- D1 Database باسم DB
- R2 Bucket باسم MEDIA

D1:
نفّذ schema.sql على قاعدة D1.

Environment variables / Secrets:
DISCORD_CLIENT_ID = Application ID من Discord Developer Portal
DISCORD_CLIENT_SECRET = Client Secret (Secret)
DISCORD_BOT_TOKEN = Token البوت (Secret)
OWNER_DISCORD_ID = Discord User ID لصاحب الموقع (Secret)
SESSION_SECRET = كلمة سر عشوائية طويلة (Secret)
DISCORD_REDIRECT_URI = https://YOUR-DOMAIN.com/oauth/callback
DISCORD_BOT_PERMISSIONS = صلاحيات البوت كرقم Discord permissions integer (اختياري، الافتراضي 0)
MEDIA_PUBLIC_URL = رابط عام لـ R2 مثل https://media.example.com (مطلوب للصور)

Discord Developer Portal:
OAuth2 > Redirects:
أضف نفس قيمة DISCORD_REDIRECT_URI بالضبط.

Cloudflare R2:
أنشئ Bucket ثم اربطه بالمشروع باسم MEDIA.
لرفع الصور من الموقع يجب أن يكون MEDIA_PUBLIC_URL رابطًا عامًا للـbucket عبر Custom Domain أو public bucket.

ملاحظة:
لا تضع DISCORD_CLIENT_SECRET أو DISCORD_BOT_TOKEN داخل index.html. يجب أن تكون Secrets في Cloudflare.

إذا كانت قاعدة D1 القديمة عندك تحتوي جدول announcement من النسخة السابقة، نفّذ مرة واحدة:
ALTER TABLE announcement ADD COLUMN image_url TEXT NOT NULL DEFAULT '';
ثم أنشئ جدول sessions بالأمر الموجود في schema.sql، وأضف access_expires_at إذا كان جدول sessions موجودًا من نسخة سابقة.
الأفضل للمشروع الجديد استخدام schema.sql كاملًا على قاعدة D1 جديدة.
