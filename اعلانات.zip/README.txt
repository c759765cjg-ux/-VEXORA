VEXORA مع لوحة تحكم للإعلانات

اللوحة: /admin/
قاعدة البيانات: Cloudflare D1
المتغير السري المطلوب: ADMIN_PASSWORD
اسم ربط D1 المطلوب في Pages Functions: DB

مهم: لأن Pages Functions تحتاج نشرًا عبر Git أو Wrangler، الرفع المباشر من لوحة Pages لا يدعم Functions حاليًا.
الخطوات:
1) ارفع المشروع إلى GitHub.
2) أنشئ D1 Database في Cloudflare.
3) نفّذ schema.sql على قاعدة البيانات.
4) اربط D1 بالمشروع باسم المتغير DB.
5) أضف Secret باسم ADMIN_PASSWORD.
6) أعد النشر.
