export async function onRequestGet({ env }) {
  const row = await env.DB.prepare("SELECT title,text,enabled FROM announcement WHERE id=1").first();
  return Response.json(row || {title:"",text:"",enabled:0}, {headers:{"Cache-Control":"no-store"}});
}
export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(()=>null);
  if (!body || typeof body.password !== "string" || body.password !== env.ADMIN_PASSWORD)
    return Response.json({error:"كلمة المرور غير صحيحة"}, {status:401});
  const title = String(body.title || "").slice(0,120);
  const text = String(body.text || "").slice(0,1000);
  const enabled = body.enabled ? 1 : 0;
  await env.DB.prepare("INSERT INTO announcement(id,title,text,enabled) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,text=excluded.text,enabled=excluded.enabled")
    .bind(title,text,enabled).run();
  return Response.json({ok:true});
}
