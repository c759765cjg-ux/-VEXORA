CREATE TABLE IF NOT EXISTS announcement (
 id INTEGER PRIMARY KEY,
 title TEXT NOT NULL DEFAULT '',
 text TEXT NOT NULL DEFAULT '',
 enabled INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO announcement(id,title,text,enabled) VALUES (1,'📢 إعلان VEXORA','اكتب إعلانك من لوحة التحكم.',0);
